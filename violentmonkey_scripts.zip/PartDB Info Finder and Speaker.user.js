// ==UserScript==
// @name        PartDB Info Finder and Speaker
// @namespace   Violentmonkey Scripts
// @match       https://YOURWEBSITE/*
// @grant       none
// @version     1.8
// @author      BangerTECH
// @description Partfinder mit Sprachausgabe
// ==/UserScript==

(function() {
    'use strict';

    window.findPartInfo = function() {
        let partName = '';
        let partId = '';

        // Finden des Namens
        const nameElement = document.querySelector("h3.w-fit");
        if (nameElement) {
            partName = nameElement.childNodes[0]?.textContent.trim();
        }

        // Finden der ID
        const floatEndElements = document.querySelectorAll(".float-end");
        if (floatEndElements.length > 0) {
            const content = floatEndElements[0]?.textContent.split(":");
            partId = content[1]?.trim();
        }

        console.log('Gefundener Name:', partName);
        console.log('Gefundene ID:', partId);

        // Überprüfung, ob Name und ID vorhanden sind
        if (partName && partId) {
            const encodedName = encodeURIComponent(partName);
            const url1 = `https://YOURWEBSITE/partinfo?name=${encodedName}&id=${encodeURIComponent(partId)}`;
            const url2 = `https://YOURWEBSITE/inventoryname?getNAME=${encodedName}`;

            console.log('Konstruierte URL 1:', url1);
            console.log('Konstruierte URL 2:', url2);

            // API-Aufruf an URL 1
            fetch(url1, { mode: 'cors' })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Daten erfolgreich empfangen von URL 1:', data);
                    speakPartInfo(data);
                })
                .catch(error => {
                    console.error('Fehler beim Senden der Daten an URL 1:', error);
                });

            // API-Aufruf an URL 2
            fetch(url2, { mode: 'cors' })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.text();
                })
                .then(data => {
                    console.log('Daten erfolgreich gesendet an URL 2:', data);
                })
                .catch(error => {
                    console.error('Fehler beim Senden der Daten an URL 2:', error);
                });
        } else {
            console.log('Keine gültigen Daten gefunden. Sprachausgabe wird übersprungen.');
        }
    };

    function speakPartInfo(data) {
        const speechText = data.speechText;
        if (!speechText) {
            console.log('Keine gültigen Daten für Sprachausgabe vorhanden.');
            return;
        }
        console.log('Text für Sprachausgabe:', speechText);
        setTimeout(() => {
            const utterance = new SpeechSynthesisUtterance(speechText);
            utterance.lang = 'de-DE';
            utterance.onerror = function(event) {
                console.error('Fehler bei der Sprachausgabe:', event);
            };
            speechSynthesis.speak(utterance);
        }, 100);
    }

    // Ausführen der Funktion beim Laden der Seite
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', findPartInfo);
    } else {
        findPartInfo();
    }

    // MutationObserver für relevante DOM-Änderungen
    const observer = new MutationObserver((mutations) => {
        for (let mutation of mutations) {
            if (mutation.type === 'childList' && mutation.target.matches('h3.w-fit')) {
                findPartInfo();
                break;
            }
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });
})();