// ==UserScript==
// @name        PartDB Info Finder with Popup
// @namespace   Violentmonkey Scripts
// @match       https://YOURWEBSITE/*
// @grant       none
// @version     2.3
// @author      BangerTECH
// @description Partfinder mit Popup-Anzeige und Namensanzeige im Dashboard
// ==/UserScript==

(function() {
    'use strict';

    window.findPartInfo = function() {
        let partName = '';
        let partId = '';

        // Finden des Namens
        const nameElement = document.querySelector("h3.w-fit");
        if (nameElement) {
            partName = nameElement.childNodes[0]?.textContent.trim();
        }

        // Finden der ID
        const floatEndElements = document.querySelectorAll(".float-end");
        if (floatEndElements.length > 0) {
            const content = floatEndElements[0]?.textContent.split(":");
            partId = content[1]?.trim();
        }

        console.log('Gefundener Name:', partName);
        console.log('Gefundene ID:', partId);

        // Überprüfung, ob Name und ID vorhanden sind
        if (partName && partId) {
            const encodedName = encodeURIComponent(partName);
            const url1 = `https://YOURWEBSITE/partinfo?name=${encodedName}&id=${encodeURIComponent(partId)}`;
            const url2 = `https://YOURWEBSITE/inventoryname?getNAME=${encodedName}`;

            console.log('Konstruierte URL 1:', url1);
            console.log('Konstruierte URL 2:', url2);

            // API-Aufruf an URL 1 für Popup-Daten
            fetch(url1, { mode: 'cors' })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Daten erfolgreich empfangen von URL 1:', data);
                    showPopup(data); // Zeigt das Popup an
                })
                .catch(error => {
                    console.error('Fehler beim Senden der Daten an URL 1:', error);
                });

            // API-Aufruf an URL 2 für Namensanzeige im Dashboard
            fetch(url2, { mode: 'cors' })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.text();
                })
                .then(data => {
                    console.log('Daten erfolgreich gesendet an URL 2:', data);
                })
                .catch(error => {
                    console.error('Fehler beim Senden der Daten an URL 2:', error);
                });
        } else {
            console.log('Keine gültigen Daten gefunden. Popup wird nicht angezeigt.');
        }
    };

    // Funktion zum Anzeigen des Popups
    function showPopup(data) {
        const { speechText } = data;

        // Falls keine Daten vorhanden sind
        if (!speechText) {
            console.log('Keine gültigen Daten für Popup.');
            return;
        }

        // Überprüfen, ob ein Popup bereits existiert
        let popup = document.getElementById('partdb-popup');
        if (!popup) {
            popup = document.createElement('div');
            popup.id = 'partdb-popup';
            popup.style.position = 'fixed';
            popup.style.top = '50%';
            popup.style.left = '50%';
            popup.style.transform = 'translate(-50%, -50%)';
            popup.style.backgroundColor = '#ffffff';
            popup.style.border = '1px solid #ccc';
            popup.style.boxShadow = '0px 4px 6px rgba(0, 0, 0, 0.1)';
            popup.style.borderRadius = '12px';
            popup.style.padding = '20px';
            popup.style.zIndex = '9999';
            popup.style.fontFamily = 'Arial, sans-serif';
            popup.style.color = '#333';
            popup.style.width = '320px';
            popup.style.textAlign = 'left';
            document.body.appendChild(popup);
        }

        // Setze den Inhalt des Popups
        popup.innerHTML = `
            <div style="margin-bottom: 16px; text-align: center;">
                <strong style="font-size: 18px;">Bauteil-Informationen</strong>
            </div>
            <div style="line-height: 1.8; font-size: 16px;">
                ${speechText.split(', ').map(line => `<div>${line}</div>`).join('')}
            </div>
            <div style="text-align: center; margin-top: 20px;">
                <button id="close-popup" style="
                    background-color: #ff5c5c;
                    color: white;
                    border: none;
                    padding: 10px 15px;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 14px;">
                    Schließen
                </button>
            </div>
        `;

        // Schließen-Funktion
        const closeButton = document.getElementById('close-popup');
        closeButton.onclick = () => {
            popup.remove();
        };
    }

    // Ausführen der Funktion beim Laden der Seite
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', findPartInfo);
    } else {
        findPartInfo();
    }

    // MutationObserver für relevante DOM-Änderungen
    const observer = new MutationObserver((mutations) => {
        for (let mutation of mutations) {
            if (mutation.type === 'childList' && mutation.target.matches('h3.w-fit')) {
                findPartInfo();
                break;
            }
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

})();