// ==UserScript==
// @name        PartDB Name Finder
// @namespace   Violentmonkey Scripts
// @match       https://parts.server24-7.net/*
// @grant       none
// @version     1.2
// @author      BangerTECH
// @description Partfinder-Pixel-2
// ==/UserScript==

(function() {
    'use strict';

// Funktion zum Finden des Namens
function findPartName() {
    // Suchen Sie nach dem Element mit der Klasse "w-fit" innerhalb eines h3-Tags
    var nameElement = document.querySelector("h3.w-fit");
    if (nameElement) {
        // Extrahieren Sie nur den Textteil, ohne den Edit-Link
        let partName = nameElement.childNodes[0].textContent.trim();

        // Encode den Namen für die URL
        let encodedName = encodeURIComponent(partName);

        const url = 'https://nodered.server24-7.net/inventoryname?getNAME=' + encodedName;

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(data => {
                console.log('GET-Anfrage erfolgreich gesendet:', data);
            })
            .catch(error => {
                console.error('Fehler beim Senden der GET-Anfrage:', error);
            });
    } else {
        console.log('Element mit Klasse "w-fit" innerhalb eines h3-Tags nicht gefunden');
    }
}


    // Führen Sie die Funktion aus, wenn das Dokument geladen ist
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', findPartName);
    } else {
        findPartName();
    }

    // Fügen Sie einen MutationObserver hinzu, um Änderungen im DOM zu überwachen
    const observer = new MutationObserver(findPartName);
    observer.observe(document.body, { childList: true, subtree: true });
})();
